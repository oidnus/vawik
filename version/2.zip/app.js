class AudioRecorder {
    constructor() {
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.isRecording = false;
        this.startTime = null;
        this.timerInterval = null;
        this.backupInterval = null;
        this.stream = null;
        this.currentRecordingId = null;
        this.isResetting = false;
        this.isCancelling = false;
        
        this.recordButton = document.getElementById('recordButton');
        this.status = document.getElementById('status');
        this.duration = document.getElementById('duration');
        this.recordingsList = document.getElementById('recordingsList');
        this.recordingControls = document.getElementById('recordingControls');
        this.resetButton = document.getElementById('resetButton');
        this.cancelButton = document.getElementById('cancelButton');
        
        this.init();
    }
    
    async init() {
        this.recordButton.addEventListener('click', () => {
            if (this.isRecording) {
                this.stopRecording();
            } else {
                this.startRecording();
            }
        });
        
        this.resetButton.addEventListener('click', () => {
            this.resetRecording();
        });
        
        this.cancelButton.addEventListener('click', () => {
            this.cancelRecording();
        });
        
        // Sprawdź czy jest przerwane nagranie do odzyskania
        this.checkForInterruptedRecording();
        
        this.loadRecordings();
        
        // Żądanie uprawnień do mikrofonu przy starcie
        try {
            await navigator.mediaDevices.getUserMedia({ audio: true });
            this.status.textContent = 'Dotknij aby nagrać';
        } catch (error) {
            this.status.textContent = 'Brak dostępu do mikrofonu';
            console.error('Błąd dostępu do mikrofonu:', error);
        }
    }
    
    async startRecording() {
        try {
            // Żądanie dostępu do mikrofonu z wysoką jakością dla iPhone
            this.stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    sampleRate: 44100,
                    channelCount: 1,
                    volume: 1.0,
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
            });
            
            // Sprawdzenie czy MediaRecorder obsługuje webm lub mp4
            let mimeType = 'audio/webm';
            if (!MediaRecorder.isTypeSupported(mimeType)) {
                mimeType = 'audio/mp4';
                if (!MediaRecorder.isTypeSupported(mimeType)) {
                    mimeType = 'audio/wav';
                }
            }
            
            this.mediaRecorder = new MediaRecorder(this.stream, {
                mimeType: mimeType
            });
            
            this.audioChunks = [];
            this.isRecording = true;
            this.startTime = Date.now();
            this.currentRecordingId = Date.now();
            
            // Zapisz stan nagrywania w localStorage
            this.saveRecordingState();
            
            this.mediaRecorder.addEventListener('dataavailable', (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
            });
            
            this.mediaRecorder.addEventListener('stop', () => {
                // Sprawdź czy to normalne zatrzymanie (nie reset, nie anulowanie)
                if (this.audioChunks.length > 0 && !this.isResetting && !this.isCancelling) {
                    this.saveRecording();
                }
                
                // Reset flag po zakończeniu
                this.isResetting = false;
                this.isCancelling = false;
                
                this.cleanup();
            });
            
            this.mediaRecorder.start(1000); // Zbieranie danych co sekundę
            
            this.updateUI();
            this.startTimer();
            this.startBackupTimer();
            
        } catch (error) {
            console.error('Błąd rozpoczęcia nagrywania:', error);
            this.status.textContent = 'Błąd: ' + error.message;
        }
    }
    
    stopRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.isRecording = false;
            this.clearRecordingState();
        }
    }
    
    cleanup() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
        
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
        
        if (this.backupInterval) {
            clearInterval(this.backupInterval);
            this.backupInterval = null;
        }
        
        this.updateUI();
    }
    
    updateUI() {
        if (this.isRecording) {
            this.recordButton.classList.add('recording');
            this.recordButton.innerHTML = '<div>⏹</div>';
            this.status.textContent = 'Nagrywanie...';
            this.recordingControls.style.display = 'flex';
        } else {
            this.recordButton.classList.remove('recording');
            this.recordButton.innerHTML = '<div>●</div>';
            this.status.textContent = 'Dotknij aby nagrać';
            this.duration.textContent = '00:00';
            this.recordingControls.style.display = 'none';
        }
    }
    
    startTimer() {
        this.timerInterval = setInterval(() => {
            if (this.isRecording && this.startTime) {
                const elapsed = Math.floor((Date.now() - this.startTime) / 1000);
                const minutes = Math.floor(elapsed / 60).toString().padStart(2, '0');
                const seconds = (elapsed % 60).toString().padStart(2, '0');
                this.duration.textContent = `${minutes}:${seconds}`;
            }
        }, 1000);
    }
    
    async saveRecording() {
        if (this.audioChunks.length === 0) return;
        
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
        const duration = Math.floor((Date.now() - this.startTime) / 1000);
        
        // Konwersja do base64 dla localStorage
        const reader = new FileReader();
        reader.onload = () => {
            const base64Audio = reader.result.split(',')[1];
            
            const recording = {
                id: this.currentRecordingId || Date.now(),
                name: `Nagranie ${new Date().toLocaleString('pl-PL')}`,
                date: new Date().toISOString(),
                duration: duration,
                audio: base64Audio,
                mimeType: audioBlob.type,
                corrupted: false
            };
            
            this.saveToStorage(recording);
            this.loadRecordings();
            
            // Wyczyść backup po udanym zapisaniu
            this.clearRecordingState();
            
            this.status.textContent = `Nagranie zapisane (${Math.floor(duration/60)}:${(duration%60).toString().padStart(2, '0')})`;
        };
        
        reader.readAsDataURL(audioBlob);
    }
    
    saveToStorage(recording) {
        let recordings = JSON.parse(localStorage.getItem('audioRecordings') || '[]');
        recordings.unshift(recording); // Dodaj na początku listy
        
        // Ograniczenie do 50 nagrań (aby nie przekroczyć limitu localStorage)
        if (recordings.length > 50) {
            recordings = recordings.slice(0, 50);
        }
        
        localStorage.setItem('audioRecordings', JSON.stringify(recordings));
    }
    
    loadRecordings() {
        const recordings = JSON.parse(localStorage.getItem('audioRecordings') || '[]');
        
        if (recordings.length === 0) {
            this.recordingsList.innerHTML = '<div class="no-recordings">Brak nagrań</div>';
            return;
        }
        
        this.recordingsList.innerHTML = recordings.map(recording => `
            <div class="recording-item ${recording.corrupted ? 'corrupted' : ''}">
                <div class="recording-info">
                    <div class="recording-name">${recording.name}</div>
                    <div class="recording-date">
                        ${new Date(recording.date).toLocaleString('pl-PL')} • 
                        ${Math.floor(recording.duration/60)}:${(recording.duration%60).toString().padStart(2, '0')}
                        ${recording.corrupted ? ' • ODZYSKANE' : ''}
                    </div>
                </div>
                <button class="play-button" onclick="recorder.playRecording('${recording.id}')">
                    ▶️ Odtwórz
                </button>
            </div>
        `).join('');
    }
    
    playRecording(id) {
        const recordings = JSON.parse(localStorage.getItem('audioRecordings') || '[]');
        const recording = recordings.find(r => r.id.toString() === id);
        
        if (!recording) return;
        
        // Konwersja base64 z powrotem do blob
        const byteCharacters = atob(recording.audio);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const audioBlob = new Blob([byteArray], { type: recording.mimeType });
        
        const audioUrl = URL.createObjectURL(audioBlob);
        const audio = new Audio(audioUrl);
        
        audio.play().catch(error => {
            console.error('Błąd odtwarzania:', error);
            this.status.textContent = 'Błąd odtwarzania nagrania';
        });
        
        audio.addEventListener('ended', () => {
            URL.revokeObjectURL(audioUrl);
        });
        
        this.status.textContent = 'Odtwarzanie nagrania...';
    }
    
    startBackupTimer() {
        // Automatyczne zapisywanie co 5 sekund
        this.backupInterval = setInterval(() => {
            if (this.isRecording && this.audioChunks.length > 0) {
                this.saveBackup();
            }
        }, 5000);
    }
    
    saveBackup() {
        if (this.audioChunks.length === 0) return;
        
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
        const currentDuration = Math.floor((Date.now() - this.startTime) / 1000);
        
        const reader = new FileReader();
        reader.onload = () => {
            const base64Audio = reader.result.split(',')[1];
            
            const backup = {
                id: this.currentRecordingId,
                chunks: base64Audio,
                startTime: this.startTime,
                duration: currentDuration,
                mimeType: audioBlob.type,
                timestamp: Date.now()
            };
            
            localStorage.setItem('recordingBackup', JSON.stringify(backup));
            console.log(`Backup zapisany: ${currentDuration}s`);
        };
        
        reader.readAsDataURL(audioBlob);
    }
    
    saveRecordingState() {
        const state = {
            isRecording: true,
            startTime: this.startTime,
            recordingId: this.currentRecordingId
        };
        localStorage.setItem('recordingState', JSON.stringify(state));
    }
    
    clearRecordingState() {
        localStorage.removeItem('recordingState');
        localStorage.removeItem('recordingBackup');
    }
    
    checkForInterruptedRecording() {
        const backup = localStorage.getItem('recordingBackup');
        
        if (backup) {
            try {
                const recordingBackup = JSON.parse(backup);
                
                // Sprawdź czy backup ma więcej niż 5 sekund (oznacza przerwane nagranie)
                if (recordingBackup.duration >= 5) {
                    // Automatycznie dodaj do listy jako uszkodzone nagranie
                    this.addCorruptedRecording(recordingBackup);
                }
                
                // Wyczyść backup po sprawdzeniu
                localStorage.removeItem('recordingBackup');
                localStorage.removeItem('recordingState');
                
            } catch (error) {
                console.error('Błąd odczytu backup:', error);
                localStorage.removeItem('recordingBackup');
                localStorage.removeItem('recordingState');
            }
        }
    }
    
    showRecoveryDialog(backup) {
        const duration = backup.duration;
        const minutes = Math.floor(duration / 60);
        const seconds = duration % 60;
        
        const message = `Znaleziono przerwane nagranie (${minutes}:${seconds.toString().padStart(2, '0')}). Czy chcesz je odzyskać?`;
        
        if (confirm(message)) {
            this.recoverRecording(backup);
        } else {
            this.clearRecordingState();
        }
    }
    
    recoverRecording(backup) {
        // Konwersja backup do nagrania
        const byteCharacters = atob(backup.chunks);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const audioBlob = new Blob([byteArray], { type: backup.mimeType });
        
        const reader = new FileReader();
        reader.onload = () => {
            const base64Audio = reader.result.split(',')[1];
            
            const recording = {
                id: backup.id,
                name: `Odzyskane nagranie ${new Date(backup.startTime).toLocaleString('pl-PL')}`,
                date: new Date(backup.startTime).toISOString(),
                duration: backup.duration,
                audio: base64Audio,
                mimeType: backup.mimeType
            };
            
            this.saveToStorage(recording);
            this.loadRecordings();
            this.clearRecordingState();
            
            this.status.textContent = `Nagranie odzyskane (${Math.floor(backup.duration/60)}:${(backup.duration%60).toString().padStart(2, '0')})`;
        };
        
        reader.readAsDataURL(audioBlob);
    }
    
    addCorruptedRecording(backup) {
        // Sprawdź czy to nagranie już nie istnieje
        const existingRecordings = JSON.parse(localStorage.getItem('audioRecordings') || '[]');
        const exists = existingRecordings.find(r => r.id === backup.id);
        
        if (exists) {
            console.log('Nagranie już istnieje, pomijam odzyskiwanie');
            return;
        }
        
        const byteCharacters = atob(backup.chunks);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const audioBlob = new Blob([byteArray], { type: backup.mimeType });
        
        const reader = new FileReader();
        reader.onload = () => {
            const base64Audio = reader.result.split(',')[1];
            
            const recording = {
                id: backup.id,
                name: `🔧 PRZERWANE: ${new Date(backup.startTime).toLocaleString('pl-PL')}`,
                date: new Date(backup.startTime).toISOString(),
                duration: backup.duration,
                audio: base64Audio,
                mimeType: backup.mimeType,
                corrupted: true
            };
            
            this.saveToStorage(recording);
            this.status.textContent = `Odzyskano przerwane nagranie (${Math.floor(backup.duration/60)}:${(backup.duration%60).toString().padStart(2, '0')})`;
        };
        
        reader.readAsDataURL(audioBlob);
    }
    
    resetRecording() {
        if (!this.isRecording) return;
        
        // Ustaw flagę resetowania
        this.isResetting = true;
        
        // Zatrzymaj obecne nagrywanie
        if (this.mediaRecorder) {
            this.mediaRecorder.stop();
        }
        
        // Wyczyść dane
        this.audioChunks = [];
        
        // Rozpocznij nowe nagrywanie po chwili
        this.status.textContent = 'Resetowanie...';
        setTimeout(() => {
            this.startRecording();
        }, 200);
    }
    
    cancelRecording() {
        if (!this.isRecording) return;
        
        // Ustaw flagę anulowania
        this.isCancelling = true;
        this.isRecording = false;
        
        // Zatrzymaj nagrywanie
        if (this.mediaRecorder) {
            this.mediaRecorder.stop();
        }
        
        // Wyczyść wszystkie dane bez zapisywania
        this.audioChunks = [];
        this.clearRecordingState();
        
        this.status.textContent = 'Nagrywanie anulowane';
        setTimeout(() => {
            this.status.textContent = 'Dotknij aby nagrać';
        }, 2000);
    }
}

// Inicjalizacja aplikacji
let recorder;
document.addEventListener('DOMContentLoaded', () => {
    recorder = new AudioRecorder();
});

// Dodatkowe wsparcie dla iOS
document.addEventListener('touchstart', function() {}, { passive: true });